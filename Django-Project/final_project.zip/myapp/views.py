from django.shortcuts import render
# Create your views here.
from django.http import HttpResponse
from myapp.models import SignUp


def homepageview(request):
    return render(request, 'home.html')

def aboutpageview(request):
    return render(request, 'about.html')

def contactpageview(request):
    return render(request, 'contact.html')

def formview(request):
    if request.method == 'POST':
        fname = str(request.POST['fname'])  
        lname = str(request.POST['lname'])  
        email = str(request.POST['email'])  
        cpass = str(request.POST['cpass'])  
        copass = str(request.POST['copass'])  
        mnum = str(request.POST['mnum'])  
        byear = str(request.POST['byear'])

        print(fname, lname, email, cpass, copass, mnum, byear)

        ins = SignUp(fname=fname, lname=lname, email=email, cpass=cpass, copass=copass, mnum=mnum, byear=byear)
        ins.save()
        print("Data stored successfully")

    return render(request, 'form.html')


    
