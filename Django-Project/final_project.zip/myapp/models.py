from django.db import models

# Create your models here.

class SignUp(models.Model):
    fname = models.CharField(max_length=50)
    lname = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    cpass = models.CharField(max_length=50)
    copass = models.CharField(max_length=50)
    mnum = models.CharField(max_length=50)
    byear = models.CharField(max_length=50)
    
